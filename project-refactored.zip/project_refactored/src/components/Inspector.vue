<template>
  <div v-if="!field"><p class="muted">Select a field from the canvas to edit.</p></div>
  <div v-else class="stack">
    <div class="muted">Type: {{ field.type }}</div>

    <!-- Label / Text -->
    <div v-if="field.type !== 'heading' && field.type !== 'paragraph'">
      <label>Label</label>
      <input type="text" v-model="field.label" class="input">
    </div>
    <div v-else>
      <label>Text</label>
      <input type="text" v-model="field.value" class="input">
    </div>

    <!-- Placeholder -->
    <div v-if="['text','email','textarea','date','time'].includes(field.type)">
      <label>Placeholder</label>
      <input type="text" v-model="field.placeholder" class="input">
    </div>

    <!-- Options (select/radio) -->
    <div v-if="['select','radio'].includes(field.type)">
      <label>Options (comma separated)</label>
      <input type="text" class="input" :value="(field.options||[]).join(', ')" @input="updateOptions($event)">
    </div>

    <!-- Required -->
    <div>
      <label class="checkbox">
        <input type="checkbox" v-model="field.required">
        <span>Required</span>
      </label>
    </div>

    <!-- Help text -->
    <div>
      <label>Help text</label>
      <input type="text" v-model="field.help" class="input">
    </div>

    <!-- Link field -->
    <template v-if="field.type==='link'">
      <div>
        <label>URL</label>
        <input type="text" v-model="field.href" class="input">
      </div>
      <div>
        <label>Target</label>
        <select v-model="field.target" class="input">
          <option value="">Same tab</option>
          <option value="_blank">New tab</option>
        </select>
      </div>
    </template>

    <!-- Button field -->
    <template v-if="field.type==='button'">
      <div>
        <label>Action</label>
        <select v-model="field.action" class="input">
          <option value="">None</option>
          <option value="submit">Submit</option>
          <option value="reset">Reset</option>
        </select>
      </div>
    </template>

    <div style="display:flex; justify-content:flex-end">
      <button class="btn" @click="delField">Delete</button>
    </div>
  </div>
</template>

<script>
export default {
  name: 'Inspector',
  props: { schema: { type: Object, required: true }, selected: { type: Object, default: () => ({ step:0, index:-1 }) } },
  emits: ['update:selected'],
  computed: {
    field(){
      const s = this.selected
      const step = this.schema.steps[s.step]; if(!step) return null
      const top = (step.fields || [])[s.index] || null
      if(!top) return null
      if (typeof s.col === 'number' && typeof s.cindex === 'number' && top && top.cols){
        return (top.cols[s.col] || [])[s.cindex] || null
      }
      return top
    }
  },
  methods: {
    updateOptions(e){ this.field.options = e.target.value.split(',').map(s=>s.trim()).filter(Boolean) },
    delField(){
      const s = this.selected
      const step = this.schema.steps[s.step]
      if(typeof s.col === 'number' && typeof s.cindex === 'number'){
        const container = step.fields[s.index]
        if(container && container.cols && container.cols[s.col]){
          container.cols[s.col].splice(s.cindex, 1)
          this.$emit('update:selected', { step: s.step, index: s.index, col: undefined, cindex: undefined })
          return
        }
      }
      step.fields.splice(s.index, 1)
      this.$emit('update:selected', { step: s.step, index:-1 })
    }
  }
}
</script>
