
<template>
  <div v-show="open" class="modal-backdrop" role="dialog" aria-modal="true" @click.self="$emit('update:open', false)">
    <div class="modal">
      <div class="modal-header">
        <div style="display:flex;align-items:center;gap:12px">
          <h2>Preview</h2>
          <div class="stepperTop">
            <div v-for="(s,i) in schema.steps" :key="s.id" class="stepDot" :class="{active: i===step}">
              <div style="width:10px;height:10px;border-radius:999px" :style="{background: i===step ? '#0ea5b7' : '#e5e7eb'}"></div>
              <button class="btn" @click="step = i">{{ s.title }}</button>
            </div>
          </div>
        </div>
        <div class="tabs" role="tablist">
          <button class="tab" :class="{active: mode==='desktop'}" @click="mode='desktop'">Desktop</button>
          <button class="tab" :class="{active: mode==='mobile'}" @click="mode='mobile'">Mobile</button>
        </div>
        <button class="close" @click="$emit('update:open', false)">×</button>
      </div>
      <div class="modal-body">
        <section v-show="mode==='desktop'">
          <div class="card"><div class="stack">
            <template v-for="(f,i) in (schema.steps[step].fields || [])" :key="i">
              
<div v-if="isDisplayBlock(f)" class="section-title">{{ f.value || f.label }}</div>
          <template v-else-if="f.type==='layout-2col'">
            <div class="layout-card">
              <div class="cols">
                <div class="stack">
                  <template v-for="(cf,cfi) in (f.cols && f.cols[0] || [])" :key="'PL'+cfi">
                    <div class="field">
                      <label v-if="cf.label">{{ cf.label }} <span v-if="cf.required" style="color:#ef4444">*</span></label>
                      <div v-if="cf.type==='radio'" class="radio-group">
                        <label v-for="o in (cf.options||[])" :key="o" style="display:flex;gap:8px;align-items:center;">
                          <input type="radio" :name="'prc-'+i+'-'+cfi" :value="o"> <span>{{ o }}</span>
                        </label>
                      </div>
                      <select v-else-if="cf.type==='select'" class="input">
                        <option v-for="o in (cf.options||[])" :key="o">{{ o }}</option>
                      </select>
                      <textarea v-else-if="cf.type==='textarea'" class="input" :placeholder="cf.placeholder"></textarea>
                      <input v-else-if="['text','email','date','time'].includes(cf.type)" :type="cf.type" class="input" :placeholder="cf.placeholder" />
                      <div v-else class="muted">[ {{ cf.type }} block ]</div>
                      <div v-if="cf.help" class="muted">{{ cf.help }}</div>
                    </div>
                  </template>
                </div>
                <div class="stack">
                  <template v-for="(cf,cfi) in (f.cols && f.cols[1] || [])" :key="'PR'+cfi">
                    <div class="field">
                      <label v-if="cf.label">{{ cf.label }} <span v-if="cf.required" style="color:#ef4444">*</span></label>
                      <div v-if="cf.type==='radio'" class="radio-group">
                        <label v-for="o in (cf.options||[])" :key="o" style="display:flex;gap:8px;align-items:center;">
                          <input type="radio" :name="'prc-'+i+'-'+cfi" :value="o"> <span>{{ o }}</span>
                        </label>
                      </div>
                      <select v-else-if="cf.type==='select'" class="input">
                        <option v-for="o in (cf.options||[])" :key="o">{{ o }}</option>
                      </select>
                      <textarea v-else-if="cf.type==='textarea'" class="input" :placeholder="cf.placeholder"></textarea>
                      <input v-else-if="['text','email','date','time'].includes(cf.type)" :type="cf.type" class="input" :placeholder="cf.placeholder" />
                      <div v-else class="muted">[ {{ cf.type }} block ]</div>
                      <div v-if="cf.help" class="muted">{{ cf.help }}</div>
                    </div>
                  </template>
                </div>
              </div>
            </div>
          </template>
          <div v-else class="field">

                <label v-if="f.label">{{ f.label }} <span v-if="f.required" style="color:#ef4444">*</span></label>
                <div v-if="f.type==='radio'" class="radio-group">
                  <label v-for="o in (f.options||[])" :key="o" style="display:flex;gap:8px;align-items:center;">
                    <input type="radio" :name="'pr-'+i" :value="o"> <span>{{ o }}</span>
                  </label>
                </div>
                <select v-else-if="f.type==='select'" class="input">
                  <option v-for="o in (f.options||[])" :key="o">{{ o }}</option>
                </select>
                <textarea v-else-if="f.type==='textarea'" class="input" :placeholder="f.placeholder"></textarea>
                <input v-else-if="['text','email','date','time'].includes(f.type)" :type="f.type" class="input" :placeholder="f.placeholder" />
                <div v-else class="muted">[ {{ f.type }} block ]</div>
                <div v-if="f.help" class="muted">{{ f.help }}</div>
              </div>
            </template>
          </div></div>
          <div class="footerBar">
            <button class="btn" @click="back" :disabled="step===0">Back</button>
            <button class="btn primary" @click="next" :disabled="step===schema.steps.length-1">Next →</button>
          </div>
        </section>

        <section v-show="mode==='mobile'">
          <div class="mobile-frame">
            <div class="mobile-bar">{{ schema.steps[step].title }}</div>
            <div class="mobile-content">
              <div class="stack">
                <template v-for="(f,i) in (schema.steps[step].fields || [])" :key="'M'+i">
                  <div v-if="isDisplayBlock(f)" class="section-title">{{ f.value || f.label }}</div>

                  <template v-else-if="f.type==='layout-2col'">
                    <div class="layout-card">
                      <div class="layout-head">
                        <strong>2 Columns</strong>
                        <span class="muted">Drop fields into Left / Right</span>
                      </div>
                      <div class="cols">
                        <div class="col-drop">
                          <div class="col-title">Left</div>
                          <div class="stack">
                            <template v-for="(cf,cfi) in (f.cols && f.cols[0] || [])" :key="'ML'+cfi">
                              <div class="field">
                                <label v-if="cf.label">{{ cf.label }} <span v-if="cf.required" class="req">*</span></label>
                                <div v-if="cf.type==='radio'" class="radio-group">
                                  <label v-for="o in (cf.options||[])" :key="o" class="radio">
                                    <input type="radio" :name="'mrc-'+i+'-'+cfi" :value="o"> <span>{{ o }}</span>
                                  </label>
                                </div>
                                <select v-else-if="cf.type==='select'" class="input">
                                  <option v-for="o in (cf.options||[])" :key="o">{{ o }}</option>
                                </select>
                                <textarea v-else-if="cf.type==='textarea'" class="input" :placeholder="cf.placeholder"></textarea>
                                <input v-else-if="['text','email','date','time'].includes(cf.type)" :type="cf.type" class="input" :placeholder="cf.placeholder" />
                                <div v-else class="muted">[ {{ cf.type }} block ]</div>
                                <div v-if="cf.help" class="muted">{{ cf.help }}</div>
                              </div>
                            </template>
                            <div class="empty">Drop here</div>
                          </div>
                        </div>

                        <div class="col-drop">
                          <div class="col-title">Right</div>
                          <div class="stack">
                            <template v-for="(cf,cfi) in (f.cols && f.cols[1] || [])" :key="'MR'+cfi">
                              <div class="field">
                                <label v-if="cf.label">{{ cf.label }} <span v-if="cf.required" class="req">*</span></label>
                                <div v-if="cf.type==='radio'" class="radio-group">
                                  <label v-for="o in (cf.options||[])" :key="o" class="radio">
                                    <input type="radio" :name="'mrc-'+i+'-'+cfi" :value="o"> <span>{{ o }}</span>
                                  </label>
                                </div>
                                <select v-else-if="cf.type==='select'" class="input">
                                  <option v-for="o in (cf.options||[])" :key="o">{{ o }}</option>
                                </select>
                                <textarea v-else-if="cf.type==='textarea'" class="input" :placeholder="cf.placeholder"></textarea>
                                <input v-else-if="['text','email','date','time'].includes(cf.type)" :type="cf.type" class="input" :placeholder="cf.placeholder" />
                                <div v-else class="muted">[ {{ cf.type }} block ]</div>
                                <div v-if="cf.help" class="muted">{{ cf.help }}</div>
                              </div>
                            </template>
                            <div class="empty">Drop here</div>
                          </div>
                        </div>
                      </div>
                    </div>
                  </template>

                  <div v-else class="field">
                    <label v-if="f.label">{{ f.label }} <span v-if="f.required" class="req">*</span></label>
                    <div v-if="f.type==='radio'" class="radio-group">
                      <label v-for="o in (f.options||[])" :key="o" class="radio">
                        <input type="radio" :name="'pm-'+i" :value="o"> <span>{{ o }}</span>
                      </label>
                    </div>
                    <select v-else-if="f.type==='select'" class="input">
                      <option v-for="o in (f.options||[])" :key="o">{{ o }}</option>
                    </select>
                    <textarea v-else-if="f.type==='textarea'" class="input" :placeholder="f.placeholder"></textarea>
                    <input v-else-if="['text','email','date','time'].includes(f.type)" :type="f.type" class="input" :placeholder="f.placeholder" />
                    <div v-else class="muted">[ {{ f.type }} block ]</div>
                    <div v-if="f.help" class="muted">{{ f.help }}</div>
                  </div>
                </template>
</div>
            </div>
          </div>
        </section>
      </div>
    </div>
  </div>
</template>

<script>
export default {
  name: 'PreviewModal',
  props: { open: { type: Boolean, default: false }, schema: { type: Object, required: true } },
  emits: ['update:open'],
  data(){ return { mode: 'desktop', step: 0 } },
  methods: {
    isDisplayBlock(f){ return f.type === 'heading' || f.type === 'paragraph' },
    next(){ if(this.step < this.schema.steps.length-1) this.step++ },
    back(){ if(this.step > 0) this.step-- },
  }
}
</script>


<style scoped>
.layout-card{ border:2px dashed #e5e7eb; border-radius:12px; padding:12px; }
.layout-head{ display:flex; justify-content:space-between; align-items:center; margin-bottom:8px; }
.cols{ display:grid; grid-template-columns: 1fr 1fr; gap:20px; gap:12px; }
.col-drop{ border:2px dashed #dbe2ea; border-radius:10px; padding: 16px; background:#fff; min-height: 180px; padding: 16px;}
.col-title{ font-weight:600; margin-bottom:6px; }
.empty{ text-align:center; color:#6b7280; padding:10px; border-radius:8px;  min-height: 90px; padding: 16px; border: 2px dashed #e5e7eb; background:#fafafa; }
.muted{ color:#6b7280; }

.field.inner{ margin-bottom:12px; }
</style>
