
<template>
  <div v-show="open" class="modal-backdrop" @click.self="$emit('update:open', false)">
    <div class="modal" style="max-width:900px;">
      <div class="modal-header">
        <h2>Wizard JSON</h2>
        <button class="close" @click="$emit('update:open', false)">×</button>
      </div>
      <div class="modal-body">
        <pre style="margin:0; max-height:60vh; overflow:auto; background:#0b1220; color:#d1e7ff; padding:12px; border-radius:12px">{{ pretty }}</pre>
        <div style="display:flex;gap:8px;margin-top:10px">
          <button class="btn" @click="copy">Copy</button>
          <button class="btn primary" @click="$emit('update:open', false)">Close</button>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
export default {
  name: 'JsonPanel',
  props: { open: { type: Boolean, default: false }, schema: { type: Object, required: true } },
  emits: ['update:open'],
  computed: { pretty(){ return JSON.stringify(this.schema, null, 2) } },
  methods: {
    copy(){ navigator.clipboard.writeText(this.pretty); alert('JSON copied to clipboard') }
  }
}
</script>
