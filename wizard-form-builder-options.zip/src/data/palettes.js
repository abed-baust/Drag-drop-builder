
export const surveyPalette = [
  { title: 'Student', items: [
    {type:'text', label:'First Name', placeholder:'Enter first name'},
    {type:'text', label:'Last Name', placeholder:'Enter last name'},
    {type:'text', label:'Full Name', placeholder:'Enter full name'},
    {type:'text', label:'Degree'},
    {type:'text', label:'Major'},
    {type:'text', label:'Latin Honors'},
    {type:'text', label:'City State'},
    {type:'text', label:'Address Line 1'},
    {type:'text', label:'Address Line 2'},
    {type:'textarea', label:'Quote Statement', placeholder:'Enter details here'},
    {type:'textarea', label:'Quote Statement', placeholder:'Enter details here'},
    {type:'textarea', label:'Student Thesis', placeholder:'Enter details here'}
  ]},
  { title: 'Basic', items: [
    {type:'heading', value:'Add Text'},
    {type:'link', label:'Link'},
    {type:'image', label:'Image'},
    {type:'video', label:'Video'},
    {type:'map', label:'Map'},
    {type:'link-block', label:'Link Block'},
    {type:'audio', label:'Audio'}
  ]},
  { title: 'Forms', items: [
    {type:'form', label:'Form'},
    {type:'text', label:'Input'},
    {type:'textarea', label:'Text Area'},
    {type:'select', label:'Dropdown', options:['Option 1','Option 2']},
    {type:'button', label:'Button'},
    {type:'label', label:'Label'},
    {type:'checkbox', label:'Checkbox'},
    {type:'radio', label:'Radio', options:['Yes','No']}
  ]},
  { title: 'Custom Object', items: [
    {type:'select', label:'Participant Type', options:['Undergrad','Graduate','Faculty']},
    {type:'text', label:'College/School your Major is in'},
    {type:'radio', label:'Attending the commencement ceremony', options:['Yes','No']},
    {type:'select', label:'Job offer Status', options:['No offer yet','Pending','Accepted']},
    {type:'radio', label:'Recommendation to a friend', options:['Yes','No']},
    {type:'text', label:'Social Media'}
  ]}
]

export const demoPalette = [
  { title: 'General', items: [
    {type:'text', label:'Short Text'},
    {type:'textarea', label:'Long Text'},
    {type:'select', label:'Dropdown', options:['A','B','C']},
    {type:'radio', label:'Yes/No', options:['Yes','No']},
  ]}
]
