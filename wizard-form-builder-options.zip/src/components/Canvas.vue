
<template>
  <div class="dropzone" @drop="onDrop" @dragover="onDragOver">
    <div v-for="(f,i) in (step.fields || [])" :key="i" class="field" :class="{active: selected.index===i && selected.step===stepIndex}"
         draggable="true" @dragstart="dragStart(i, $event)" @click="pick(i)"
         @drop.prevent="onReorderDrop(i, $event)" @dragover.prevent>
      <template v-if="isDisplayBlock(f)">
        <div v-if="f.type==='heading'" class="section-title">{{ f.value || f.label }}</div>
        <p v-else class="muted">{{ f.value }}</p>
      </template>
      <template v-else>
        <label v-if="f.label">{{ f.label }} <span v-if="f.required" style="color:#ef4444">*</span></label>

        <div v-if="f.type==='radio'" class="radio-group">
          <label v-for="o in (f.options||[])" :key="o" style="display:flex;gap:8px;align-items:center;">
            <input type="radio" :name="'radio-'+i" :value="o"> <span>{{ o }}</span>
          </label>
        </div>

        <div v-else-if="f.type==='checkbox'">
          <label style="display:flex;align-items:center;gap:8px">
            <input type="checkbox"> <span>{{ f.label || 'Checkbox' }}</span>
          </label>
        </div>

        <select v-else-if="f.type==='select'" class="input">
          <option v-for="o in (f.options||[])" :key="o">{{ o }}</option>
        </select>

        <textarea v-else-if="f.type==='textarea'" class="input" :placeholder="f.placeholder"></textarea>

        <input v-else-if="['text','email','date','time'].includes(f.type)" :type="f.type" class="input" :placeholder="f.placeholder" />

        <div v-else class="muted">[ {{ f.type }} block ]</div>

        <div v-if="f.help" class="muted">{{ f.help }}</div>
      </template>
    </div>
    <div class="muted" style="text-align:center" @drop.prevent="onReorderDrop(-1, $event)" @dragover.prevent>Drop here</div>
  </div>
</template>

<script>
export default {
  name: 'Canvas',
  props: { step: { type: Object, required: true }, stepIndex: { type: Number, required: true }, selected: { type: Object, default: () => ({ step:0, index:-1 }) } },
  emits: ['update:selected'],
  methods: {
    isDisplayBlock(f){ return f.type === 'heading' || f.type === 'paragraph' },
    onDrop(e){
      const data = e.dataTransfer.getData('text/plain')
      if(!data) return
      try{
        const item = JSON.parse(data)
        if(item && item.dragType === 'move'){ return }
        this.step.fields = this.step.fields || []
        if(this.isDisplayBlock(item)){ item.value = item.value || item.label || 'Text'; delete item.label }
        this.step.fields.push(item)
        this.$emit('update:selected', { step: this.stepIndex, index: this.step.fields.length - 1 })
      }catch(_){}
    },
    onDragOver(e){ e.preventDefault() },
    pick(index){ this.$emit('update:selected', { step: this.stepIndex, index }) },
    dragStart(index, e){ e.dataTransfer.setData('text/plain', JSON.stringify({ dragType:'move', index })) },
    onReorderDrop(toIndex, e){
      const data = e.dataTransfer.getData('text/plain')
      try{
        const { index } = JSON.parse(data)
        const item = this.step.fields.splice(index, 1)[0]
        if(toIndex === -1) this.step.fields.push(item)
        else this.step.fields.splice(toIndex, 0, item)
        this.$emit('update:selected', { step: this.stepIndex, index: (toIndex === -1 ? this.step.fields.length-1 : toIndex) })
      }catch(_){}
    }
  }
}
</script>
