
<script setup>
import { computed } from 'vue'
const props = defineProps({ step: { type: Object, required: true }, stepIndex: { type: Number, required: true }, selected: { type: Object, default: () => ({ step:0, index:-1 }) } })
const emit = defineEmits(['update:selected'])

function onDrop(e){
  const data = e.dataTransfer.getData('text/plain')
  if(!data) return
  try{
    const item = JSON.parse(data)
    if(item && item.dragType === 'move'){ return }
    props.step.fields = props.step.fields || []
    if(item.type === 'heading' || item.type === 'paragraph'){
      item.value = item.value || item.label || 'Text'; delete item.label
    }
    props.step.fields.push(item)
    emit('update:selected', { step: props.stepIndex, index: props.step.fields.length - 1 })
  }catch(_){}
}
function onDragOver(e){ e.preventDefault() }
function pick(index){ emit('update:selected', { step: props.stepIndex, index }) }
function dragStart(e, index){ e.dataTransfer.setData('text/plain', JSON.stringify({ dragType:'move', index })) }
function onReorderDrop(e, toIndex){
  const data = e.dataTransfer.getData('text/plain')
  try{
    const { index } = JSON.parse(data)
    const item = props.step.fields.splice(index, 1)[0]
    if(toIndex === -1) props.step.fields.push(item)
    else props.step.fields.splice(toIndex, 0, item)
    emit('update:selected', { step: props.stepIndex, index: (toIndex === -1 ? props.step.fields.length-1 : toIndex) })
  }catch(_){}
}

function tag(f){
  switch ((f.type || 'text').toLowerCase()) {
    case 'textarea': return 'textarea'
    case 'select': return 'select'
    case 'radio': return 'radio'
    case 'checkbox': return 'checkbox'
    case 'date': return 'date'
    case 'time': return 'time'
    case 'heading': return 'heading'
    case 'paragraph': return 'paragraph'
    case 'button': return 'button'
    case 'label': return 'label'
    case 'image': return 'image'
    case 'video': return 'video'
    case 'link': return 'link'
    default: return 'input'
  }
}
</script>

<template>
  <div class="dropzone" @drop="onDrop" @dragover="onDragOver">
    <div
      v-for="(f,i) in (step.fields || [])"
      :key="i"
      class="field cardish"
      :class="{active: selected.index===i && selected.step===stepIndex}"
      draggable="true"
      @dragstart="e => dragStart(e,i)"
      @click="pick(i)"
      @drop.prevent="e => onReorderDrop(e,i)"
      @dragover.prevent
    >
      <!-- Heading / Paragraph blocks -->
      <h3 v-if="tag(f)==='heading'" class="section-title">{{ f.value || 'Heading' }}</h3>
      <p v-else-if="tag(f)==='paragraph'" class="muted">{{ f.value || 'Paragraph text' }}</p>

      <!-- Button-only / Label-only / Media / Link blocks -->
      <div v-else-if="tag(f)==='button'">
        <button class="btn primary">{{ f.label || 'Button' }}</button>
      </div>
      <div v-else-if="tag(f)==='label'">
        <div class="muted">{{ f.label || 'Label' }}</div>
      </div>
      <div v-else-if="tag(f)==='image'">
        <div class="mediaStub">Image</div>
      </div>
      <div v-else-if="tag(f)==='video'">
        <div class="mediaStub">Video</div>
      </div>
      <div v-else-if="tag(f)==='link'">
        <a href="#" @click.prevent class="muted">{{ f.label || 'Link' }}</a>
      </div>

      <!-- Form inputs -->
      <template v-else>
        <label v-if="f.label">{{ f.label }} <span v-if="f.required" style="color:#ef4444">*</span></label>

        <div v-if="tag(f)==='radio'" class="radio-group">
          <label v-for="o in (f.options||['Yes','No'])" :key="o" class="radioItem">
            <input type="radio" :name="'field-'+i" :value="o" />
            <span>{{ o }}</span>
          </label>
        </div>

        <div v-else-if="tag(f)==='checkbox'" class="checkboxItem">
          <input type="checkbox" :id="'cb-'+i" />
          <label :for="'cb-'+i">{{ f.label || 'Checkbox' }}</label>
        </div>

        <select v-else-if="tag(f)==='select'" class="input">
          <option v-for="o in (f.options||['Option 1','Option 2'])" :key="o">{{ o }}</option>
        </select>

        <textarea v-else-if="tag(f)==='textarea'" class="input" :placeholder="f.placeholder || 'Enter details here'"></textarea>

        <input
          v-else
          class="input"
          :type="tag(f)"
          :placeholder="f.placeholder || (tag(f)==='date'||tag(f)==='time' ? '' : 'Enter text')"
        />

        <div v-if="f.help" class="muted">{{ f.help }}</div>
      </template>
    </div>

    <div class="muted" style="text-align:center" @drop.prevent="e => onReorderDrop(e,-1)" @dragover.prevent>Drop here</div>
  </div>
</template>
