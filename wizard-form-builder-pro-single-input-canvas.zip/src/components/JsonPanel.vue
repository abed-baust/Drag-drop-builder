
<script setup>
import { computed } from 'vue'
const props = defineProps({ open: { type: Boolean, default: false }, schema: { type: Object, required: true } })
const emit = defineEmits(['update:open'])
const pretty = computed(() => JSON.stringify(props.schema, null, 2))
function close(){ emit('update:open', false) }
function copy(){ navigator.clipboard.writeText(pretty.value); alert('JSON copied to clipboard') }
</script>
<template>
  <div v-show="open" class="modal-backdrop" @click.self="close">
    <div class="modal" style="max-width:900px;">
      <div class="modal-header">
        <h2>Wizard JSON</h2>
        <button class="close" @click="close">×</button>
      </div>
      <div class="modal-body">
        <pre style="margin:0; max-height:60vh; overflow:auto; background:#0b1220; color:#d1e7ff; padding:12px; border-radius:12px">{{ pretty }}</pre>
        <div style="display:flex;gap:8px;margin-top:10px">
          <button class="btn" @click="copy">Copy</button>
          <button class="btn primary" @click="close">Close</button>
        </div>
      </div>
    </div>
  </div>
</template>
