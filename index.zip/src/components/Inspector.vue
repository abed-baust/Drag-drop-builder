
<script setup>
import { computed } from 'vue'
const props = defineProps({ schema: { type: Object, required: true }, selected: { type: Object, default: () => ({ step:0, index:-1 }) } })
const emit = defineEmits(['update:selected'])
const field = computed(() => {
  const s = props.selected
  const step = props.schema.steps[s.step]; if(!step) return null
  return (step.fields || [])[s.index] || null
})
function delField(){
  const s = props.selected
  const step = props.schema.steps[s.step]
  step.fields.splice(s.index, 1)
  emit('update:selected', { step: s.step, index:-1 })
}
</script>

<template>
  <div v-if="!field"><p class="muted">Select a field from the canvas to edit.</p></div>
  <div v-else>
    <div class="muted">Type: {{ field.type }}</div>
    <div v-if="field.type !== 'heading' && field.type !== 'paragraph'">
      <label>Label</label>
      <input type="text" v-model="field.label">
    </div>
    <div v-if="field.type === 'heading' || field.type === 'paragraph'">
      <label>Text</label>
      <input type="text" v-model="field.value">
    </div>
    <div v-if="['text','email','textarea','select','radio','date','time','checkbox','link','button','label'].includes(field.type)">
      <label v-if="['text','email','textarea'].includes(field.type)">Placeholder</label>
      <input v-if="['text','email','textarea'].includes(field.type)" type="text" v-model="field.placeholder">
      <label>Help text</label>
      <input type="text" v-model="field.help">
      <label>Required</label>
      <select v-model="field.required"><option :value="true">Yes</option><option :value="false">No</option></select>
      <div v-if="['select','radio'].includes(field.type)">
        <label>Options (comma separated)</label>
        <input type="text" :value="(field.options||[]).join(', ')" @input="field.options = $event.target.value.split(',').map(s=>s.trim()).filter(Boolean)">
      </div>
    </div>
    <div style="margin-top:12px;display:flex;gap:8px"><button class="btn" @click="delField">Delete</button></div>
  </div>
</template>
