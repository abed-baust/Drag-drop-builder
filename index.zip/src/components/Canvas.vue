
<script setup>
const props = defineProps({ step: { type: Object, required: true }, stepIndex: { type: Number, required: true }, selected: { type: Object, default: () => ({ step:0, index:-1 }) } })
const emit = defineEmits(['update:selected'])

function onDrop(e){
  const data = e.dataTransfer.getData('text/plain')
  if(!data) return
  try{
    const item = JSON.parse(data)
    if(item && item.dragType === 'move'){ return }
    props.step.fields = props.step.fields || []
    if(item.type === 'heading' || item.type === 'paragraph'){
      item.value = item.value || item.label || 'Text'; delete item.label
    }
    props.step.fields.push(item)
    emit('update:selected', { step: props.stepIndex, index: props.step.fields.length - 1 })
  }catch(_){}
}
function onDragOver(e){ e.preventDefault() }
function pick(index){ emit('update:selected', { step: props.stepIndex, index }) }
function dragStart(e, index){ e.dataTransfer.setData('text/plain', JSON.stringify({ dragType:'move', index })) }
function onReorderDrop(e, toIndex){
  const data = e.dataTransfer.getData('text/plain')
  try{
    const { index } = JSON.parse(data)
    const item = props.step.fields.splice(index, 1)[0]
    if(toIndex === -1) props.step.fields.push(item)
    else props.step.fields.splice(toIndex, 0, item)
    emit('update:selected', { step: props.stepIndex, index: (toIndex === -1 ? props.step.fields.length-1 : toIndex) })
  }catch(_){}
}
</script>

<template>
  <div class="dropzone" @drop="onDrop" @dragover="onDragOver">
    <div v-for="(f,i) in (step.fields || [])" :key="i" class="field" :class="{active: selected.index===i && selected.step===stepIndex}"
         draggable="true" @dragstart="e => dragStart(e,i)" @click="pick(i)"
         @drop.prevent="e => onReorderDrop(e,i)" @dragover.prevent>
      <strong>{{ f.label || f.value || (f.type + ' field') }}</strong>
      <div class="muted">{{ f.type }}</div>
    </div>
    <div class="muted" style="text-align:center" @drop.prevent="e => onReorderDrop(e,-1)" @dragover.prevent>Drop here</div>
  </div>
</template>
