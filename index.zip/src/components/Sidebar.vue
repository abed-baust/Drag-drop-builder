
<script setup>
import { ref, computed } from 'vue'
import { surveyPalette, demoPalette } from '../data/palettes.js'
const props = defineProps({ schema: { type: Object, required: true }, index: { type: Number, default: 0 } })
const emit = defineEmits(['update:index'])
const tab = ref('elements')
const step = computed(()=> props.schema.steps[props.index])
const isSurvey = computed(()=> (step.value?.title || '').toLowerCase() === 'survey')
const groups = computed(()=> isSurvey.value ? surveyPalette : demoPalette)
function drag(ev, item){ ev.dataTransfer.setData('text/plain', JSON.stringify(item)) }
</script>
<template>
  <div class="panel">
    <h3>Sidebar</h3>
    <div class="tabs3">
      <button class="tabBtn" :class="{active: tab==='elements'}" @click="tab='elements'">Elements</button>
      <button class="tabBtn" :class="{active: tab==='settings'}" @click="tab='settings'">Settings</button>
      <button class="tabBtn" :class="{active: tab==='checklist'}" @click="tab='checklist'">Checklist</button>
    </div>

    <div class="body" v-if="tab==='elements'">
      <div v-for="(g,gi) in groups" :key="gi" class="group">
        <h4>{{ g.title }} <span class="muted">ⓘ</span></h4>
        <div class="tileGrid">
          <div v-for="(t,ti) in g.items" :key="ti" class="tile" draggable="true" @dragstart="e => drag(e, t)">
            <div style="font-size:18px">📄</div>
            <div>{{ t.label || t.value }}</div>
          </div>
        </div>
      </div>
    </div>

    <div class="body" v-else-if="tab==='settings'">
      <h4>Settings</h4>
      <label style="display:flex;align-items:center;gap:8px;margin-bottom:10px">
        <input type="checkbox" v-model="step.settings.published" /> Published
      </label>
      <div v-if="isSurvey">
        <label style="display:flex;align-items:center;gap:8px;margin-bottom:10px">
          <input type="checkbox" v-model="step.settings.surveyParticipantType" />
          Participant type enable in survey form
        </label>
      </div>
      <h4>Publishing Options</h4>
      <label style="display:flex;align-items:center;gap:8px;margin-bottom:10px">
        <input type="checkbox" v-model="step.checklist.published" /> Published
      </label>
      <div style="display:grid;grid-template-columns:1fr 1fr;gap:12px">
        <div><label class="muted">Start</label><input type="date" v-model="step.settings.publishStart" /></div>
        <div><label class="muted">End</label><input type="date" v-model="step.settings.publishEnd" /></div>
      </div>
    </div>

    <div class="body" v-else>
      <h4>Checklist</h4>
      <div v-for="(it, i) in step.checklist.items" :key="i" style="display:flex;gap:8px;align-items:center;margin-bottom:8px">
        <input type="checkbox" v-model="it.done" />
        <input type="text" v-model="it.text" style="flex:1" />
        <button class="btn" @click="step.checklist.items.splice(i,1)">✕</button>
      </div>
      <button class="btn" @click="step.checklist.items.push({text:'',done:false})">+ Add More</button>
    </div>
  </div>
</template>
