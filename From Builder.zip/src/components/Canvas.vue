<template>
  <div class="dropzone" @drop="onDrop" @dragover="onDragOver">
    <div
      v-for="(f,i) in (step.fields || [])"
      :key="i"
      class="field"
      :class="{ active: selected.index===i && selected.step===stepIndex }"
      :draggable="f.type!=='layout-2col'"
      @dragstart="onTopDragStart(f, i, $event)"
      @click="pick(i)"
      @drop.stop.prevent="onReorderDrop(i, $event)"
      @dragover.prevent
    >
      <!-- display-only blocks -->
      <template v-if="isDisplayBlock(f)">
        <div v-if="f.type==='heading'" class="section-title">{{ f.value || f.label }}</div>
        <p v-else class="muted">{{ f.value }}</p>
      </template>

      <!-- 2 columns -->
      <template v-else-if="f.type==='layout-2col'">
        <div class="layout-card" @drop.stop.prevent>
          <div class="layout-head">
            <strong>2 Columns</strong>
            <span class="muted">Drop fields into Left / Right</span>
          </div>

          <div class="cols">
            <!-- LEFT -->
            <div class="col-drop"
                 @drop.stop.prevent="e => onDropIntoColumn(e, i, 0)"
                 @dragover.stop.prevent>
              <div class="col-title">Left</div>

              <div v-for="(cf,cfi) in (f.cols && f.cols[0] || [])"
                   :key="'L'+cfi"
                   class="field inner"
                   draggable="true"
                   @dragstart="dragIn(i, 0, cfi, $event)"
                   @drop.stop.prevent="onReorderIn(i, 0, cfi, $event)"
                   @dragover.stop.prevent>
                <label v-if="cf.label">{{ cf.label }} <span v-if="cf.required" class="req">*</span></label>

                <div v-if="cf.type==='radio'" class="radio-group">
                  <label v-for="o in (cf.options||[])" :key="o" class="radio">
                    <input type="radio" :name="'cr-'+i+'-'+cfi" :value="o" />
                    <span>{{ o }}</span>
                  </label>
                </div>

                <select v-else-if="cf.type==='select'" class="input">
                  <option v-for="o in (cf.options||[])" :key="o">{{ o }}</option>
                </select>

                <textarea v-else-if="cf.type==='textarea'" class="input" :placeholder="cf.placeholder"></textarea>

                <input v-else-if="['text','email','date','time'].includes(cf.type)"
                       :type="cf.type"
                       class="input"
                       :placeholder="cf.placeholder" />

                <div v-else class="muted">[ {{ cf.type }} block ]</div>

                <div v-if="cf.help" class="muted">{{ cf.help }}</div>
              </div>

              <!-- append area -->
              <div class="empty"
                   @drop.stop.prevent="e => onDropIntoColumn(e, i, 0)"
                   @dragover.stop.prevent>Drop here</div>
            </div>

            <!-- RIGHT -->
            <div class="col-drop"
                 @drop.stop.prevent="e => onDropIntoColumn(e, i, 1)"
                 @dragover.stop.prevent>
              <div class="col-title">Right</div>

              <div v-for="(cf,cfi) in (f.cols && f.cols[1] || [])"
                   :key="'R'+cfi"
                   class="field inner"
                   draggable="true"
                   @dragstart="dragIn(i, 1, cfi, $event)"
                   @drop.stop.prevent="onReorderIn(i, 1, cfi, $event)"
                   @dragover.stop.prevent>
                <label v-if="cf.label">{{ cf.label }} <span v-if="cf.required" class="req">*</span></label>

                <div v-if="cf.type==='radio'" class="radio-group">
                  <label v-for="o in (cf.options||[])" :key="o" class="radio">
                    <input type="radio" :name="'cr-'+i+'-'+cfi" :value="o" />
                    <span>{{ o }}</span>
                  </label>
                </div>

                <select v-else-if="cf.type==='select'" class="input">
                  <option v-for="o in (cf.options||[])" :key="o">{{ o }}</option>
                </select>

                <textarea v-else-if="cf.type==='textarea'" class="input" :placeholder="cf.placeholder"></textarea>

                <input v-else-if="['text','email','date','time'].includes(cf.type)"
                       :type="cf.type"
                       class="input"
                       :placeholder="cf.placeholder" />

                <div v-else class="muted">[ {{ cf.type }} block ]</div>

                <div v-if="cf.help" class="muted">{{ cf.help }}</div>
              </div>

              <!-- append area -->
              <div class="empty"
                   @drop.stop.prevent="e => onDropIntoColumn(e, i, 1)"
                   @dragover.stop.prevent>Drop here</div>
            </div>
          </div>
        </div>
      </template>

      <!-- regular controls -->
      <template v-else>
        <label v-if="f.label">{{ f.label }} <span v-if="f.required" class="req">*</span></label>

        <div v-if="f.type==='radio'" class="radio-group">
          <label v-for="o in (f.options||[])" :key="o" class="radio">
            <input type="radio" :name="'radio-'+i" :value="o" />
            <span>{{ o }}</span>
          </label>
        </div>

        <div v-else-if="f.type==='checkbox'">
          <label class="checkbox">
            <input type="checkbox" />
            <span>{{ f.label || 'Checkbox' }}</span>
          </label>
        </div>

        <select v-else-if="f.type==='select'" class="input">
          <option v-for="o in (f.options||[])" :key="o">{{ o }}</option>
        </select>

        <textarea v-else-if="f.type==='textarea'" class="input" :placeholder="f.placeholder"></textarea>

        <input v-else-if="['text','email','date','time'].includes(f.type)"
               :type="f.type"
               class="input"
               :placeholder="f.placeholder" />

        <div v-else class="muted">[ {{ f.type }} block ]</div>

        <div v-if="f.help" class="muted">{{ f.help }}</div>
      </template>
    </div>

    <!-- append at end of top level -->
    <div class="muted" style="text-align:center"
         @drop.prevent="onReorderDrop(-1, $event)"
         @dragover.prevent>Drop here</div>
  </div>
</template>

<script>
export default {
  name: 'Canvas',
  props: {
    step: { type: Object, required: true },
    stepIndex: { type: Number, required: true },
    selected: { type: Object, default: () => ({ step: 0, index: -1 }) }
  },
  emits: ['update:selected'],
  methods: {
    onTopDragStart(f, index, e){
      if(f && f.type==='layout-2col') return; // prevent dragging the whole 2-col container
      this.dragStart(index, e);
    },

    isDisplayBlock(f){
      return f && (f.type === 'heading' || f.type === 'paragraph')
    },

    onDrop(e){
      const data = e.dataTransfer.getData('text/plain')
      if(!data) return
      try{
        const item = JSON.parse(data)
        if(item && item.dragType === 'move'){
          // top-level reorders handled by onReorderDrop
          return
        }
        this.step.fields = this.step.fields || []
        if(this.isDisplayBlock(item)){
          item.value = item.value || item.label || 'Text'
          delete item.label
        }
        if(item && item.type==='layout-2col' && !item.cols){
          item.cols = [[],[]]
        }
        this.step.fields.push(item)
        this.$emit('update:selected', { step: this.stepIndex, index: this.step.fields.length - 1 })
      }catch(_){}
    },

    onDragOver(e){ e.preventDefault() },

    pick(index){
      this.$emit('update:selected', { step: this.stepIndex, index })
    },

    dragStart(index, e){
      e.dataTransfer.setData('text/plain', JSON.stringify({ dragType:'move', index }))
    },

    onReorderDrop(toIndex, e){
      const data = e.dataTransfer.getData('text/plain')
      if(!data) return
      try{
        const payload = JSON.parse(data)
        if(payload.dragType !== 'move') return
        const { index } = payload
        if(index === undefined || index === null) return
        const item = this.step.fields.splice(index, 1)[0]
        if(item && item.type==='layout-2col' && !item.cols){
          item.cols = [[],[]]
        }
        if(toIndex === -1){
          this.step.fields.push(item)
          this.$emit('update:selected', { step: this.stepIndex, index: this.step.fields.length - 1 })
        }else{
          this.step.fields.splice(toIndex, 0, item)
          this.$emit('update:selected', { step: this.stepIndex, index: toIndex })
        }
      }catch(_){}
    },

    // -------- 2-column handlers --------
    onDropIntoColumn(e, parentIndex, colIndex){
      const data = e.dataTransfer.getData('text/plain')
      if(!data) return
      const parent = this.step.fields[parentIndex]
      if(!parent.cols) parent.cols = [[],[]]

      try{
        const payload = JSON.parse(data)

        // move from a column (same or other)
        if(payload.dragType === 'move-col'){
          const { parent: fromParent, col: fromCol, index: fromIndex } = payload
          const fromArr = this.step.fields[fromParent].cols[fromCol]
          const moved = fromArr.splice(fromIndex, 1)[0]
          if(!moved) return
          const toArr = this.step.fields[parentIndex].cols[colIndex]
          toArr.push(moved) // append at bottom
          return
        }

        // moving a top-level item directly into a column -> append
        if(payload.dragType === 'move'){
          const item = this.step.fields.splice(payload.index, 1)[0]
          if(item && item.type==='layout-2col' && !item.cols){ item.cols=[[],[]] }
          const toArr = this.step.fields[parentIndex].cols[colIndex]
          toArr.push(item)
          return
        }

        // palette item → append
        const newItem = payload || {}
        if(this.isDisplayBlock(newItem)){
          newItem.value = newItem.value || newItem.label || 'Text'
          delete newItem.label
        }
        parent.cols[colIndex].push(newItem)
      }catch(_){}
    },

    dragIn(parentIndex, colIndex, index, e){
      e.dataTransfer.effectAllowed = 'move'
      e.dataTransfer.setData('text/plain', JSON.stringify({
        dragType: 'move-col',
        parent: parentIndex,
        col: colIndex,
        index
      }))
    },

    onReorderIn(parentIndex, colIndex, toIndex, e){
      const data = e.dataTransfer.getData('text/plain')
      if(!data) return
      try{
        const info = JSON.parse(data)

        // Reorder/move existing column item
        if(info.dragType === 'move-col'){
          const fromParent = info.parent
          const fromCol = info.col
          const fromIndex = info.index

          const fromArr = this.step.fields[fromParent].cols[fromCol]
          if(fromParent===parentIndex && fromCol===colIndex && (toIndex===fromIndex || toIndex===fromIndex+1)) return
          const moved = fromArr.splice(fromIndex, 1)[0]
          if(!moved) return

          const toArr = this.step.fields[parentIndex].cols[colIndex]
          let insertAt = (toIndex == null || toIndex === -1) ? toArr.length : toIndex
          // if same array and dragging downward, account for removed index
          if(fromArr === toArr && fromIndex < insertAt) insertAt = Math.max(0, insertAt - 1)

          toArr.splice(insertAt, 0, moved)
          return
        }

        // Palette item dropped on an item → insert at that position
        if(!info.dragType){
          const toArr = this.step.fields[parentIndex].cols[colIndex]
          const newItem = info
          if(this.isDisplayBlock(newItem)){
            newItem.value = newItem.value || newItem.label || 'Text'
            delete newItem.label
          }
          const insertAt = (toIndex == null || toIndex === -1) ? toArr.length : toIndex
          toArr.splice(insertAt, 0, newItem)
          return
        }

        // Moving top-level into a column by dropping on an item → insert at position
        if(info.dragType === 'move'){
          const item = this.step.fields.splice(info.index, 1)[0]
          if(item && item.type==='layout-2col' && !item.cols){ item.cols=[[],[]] }
          const toArr = this.step.fields[parentIndex].cols[colIndex]
          const insertAt = (toIndex == null || toIndex === -1) ? toArr.length : toIndex
          toArr.splice(insertAt, 0, item)
          return
        }
      }catch(_){}
    }
  }
}
</script>

<style scoped>
.dropzone{ border:2px dashed #e5e7eb; padding:12px; border-radius:12px; }
.field{ background:#fff; border-radius:10px; padding:12px; margin-bottom:10px; border:1px solid #eef2f7; }
.field.inner{ border-style:dashed; border-color:#e5e7eb; background:#fafafa; margin-bottom:12px; }

.section-title{ font-weight:600; margin-bottom:6px; }
.muted{ color:#6b7280; }
.req{ color:#ef4444; }

.layout-card{ border:2px dashed #e5e7eb; border-radius:12px; padding:12px; }
.layout-head{ display:flex; justify-content:space-between; align-items:center; margin-bottom:8px; }

.cols{ display:grid; grid-template-columns: 1fr 1fr; gap:20px; }
.col-drop{ border:2px dashed #dbe2ea; border-radius:10px; padding:16px; background:#ffffff; min-height:180px; position:relative; }
.col-title{ font-weight:600; margin-bottom:6px; }
.empty{ text-align:center; color:#6b7280; min-height:90px; padding:16px; border:2px dashed #e5e7eb; background:#fafafa; border-radius:8px; }

.radio{ display:flex; gap:8px; align-items:center; }
.checkbox{ display:flex; align-items:center; gap:8px; }
.input{ width:100%; padding:6px 8px; border:1px solid #e5e7eb; border-radius:6px; }
</style>
