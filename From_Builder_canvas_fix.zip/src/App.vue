
<template>
  <div class="topbar">
    <div class="title">Wizard Form Builder (Options API)</div>
    <div class="cta-row">
      <button class="btn" @click="newForm">New</button>
      <label class="btn" style="cursor:pointer">
        Load JSON <input type="file" accept="application/json" @change="loadForm" style="display:none">
      </label>
      <button class="btn" @click="openJson = true">Print JSON</button>
      <button class="btn primary" @click="saveForm">Save</button>
      <button class="btn" @click="openPreview = true">Preview</button>
    </div>
  </div>

  <div style="padding:12px">
    <div class="stepperTop">
      <div v-for="(s,i) in schema.steps" :key="s.id" class="stepDot" :class="{active: i===currentStepIndex}">
        <div style="width:10px;height:10px;border-radius:999px" :style="{background: i===currentStepIndex ? '#0ea5b7' : '#e5e7eb'}"></div>
        <button class="btn" @click="currentStepIndex = i">{{ s.title }}</button>
      </div>
    </div>
  </div>

  <div class="layout">
    <Sidebar :schema="schema" v-model:index="currentStepIndex" />

    <div class="panel">
      <h3>{{ currentStep.title }} — Canvas</h3>
      <div class="body canvasWrap">
        <Canvas :step="currentStep" :stepIndex="currentStepIndex" v-model:selected="selected" />
      </div>
      <div class="footerBar">
        <button class="btn" @click="goBack">Back</button>
        <div style="display:flex; gap:8px">
          <button class="btn">Save as Template</button>
          <button class="btn primary" @click="goNext">Save & Next</button>
        </div>
      </div>
    </div>

    <div class="panel inspectorDock">
      <h3>Inspector</h3>
      <div class="body">
        <Inspector :schema="schema" v-model:selected="selected" />
      </div>
    </div>
  </div>

  <PreviewModal v-model:open="openPreview" :schema="schema" />
  <JsonPanel v-model:open="openJson" :schema="schema" />
  <div class="floating-eye" title="Open Preview" @click="openPreview = true">👁️</div>

  <div class="floating-inspector" title="Open Inspector" @click="openInspector = true">🛠️</div>

  <div v-if="openInspector" class="modal-backdrop" role="dialog" aria-modal="true" @click.self="openInspector=false">
    <div class="modal" style="max-width:900px">
      <div class="modal-header">
        <h2>Inspector</h2>
        <button class="close" @click="openInspector=false">×</button>
      </div>
      <div class="modal-body">
        <Inspector :schema="schema" v-model:selected="selected" />
      </div>
    </div>
  </div>
</template>

<script>
import Sidebar from './components/Sidebar.vue'
import Canvas from './components/Canvas.vue'
import Inspector from './components/Inspector.vue'
import PreviewModal from './components/PreviewModal.vue'
import JsonPanel from './components/JsonPanel.vue'
import { downloadJson } from './utils/download.js'

export default {
  name: 'App',
  components: { Sidebar, Canvas, Inspector, PreviewModal, JsonPanel },
  data(){
    return {
      schema: this.initialSchema(),
      currentStepIndex: 0,
      selected: { step: 0, index: -1 },
      openPreview: false,
      openJson: false,
    }
  },
  computed: {
    currentStep(){ return this.schema.steps[this.currentStepIndex] }
  },
  created(){
    // lifecycle example
    console.log('App created')
  },
  mounted(){
    console.log('App mounted')
  },
  methods: {
    initialSchema(){
      const DEFAULT_STEPS = ['Survey','Registration','Slide','Guest Ticket','Photography','Name Announcement']
      const migrate = (obj) => {
        if(!obj || !Array.isArray(obj.steps)) return obj
        obj.steps.forEach(s => {
          if(Array.isArray(s.fields)) return
          const left = Array.isArray(s.left) ? s.left : []
          const right = Array.isArray(s.right) ? s.right : []
          s.fields = [...left, ...right]; delete s.left; delete s.right
        })
        return obj
      }
      const stored = localStorage.getItem('wiz-options-schema')
      if(stored){
        try{ return migrate(JSON.parse(stored)) } catch(_){}
      }
      return {
        steps: DEFAULT_STEPS.map((t,i)=>({ id: t.toLowerCase().replace(/\s+/g,'-'), title: t, fields: [], settings: { published: i===0, surveyParticipantType: true, publishStart: '', publishEnd: '' }, checklist:{ items:[{text:'Event creation', done:false}], published: i===0 } }))
      }
    },
    persist(){
      localStorage.setItem('wiz-options-schema', JSON.stringify(this.schema))
    },
    newForm(){
      localStorage.removeItem('wiz-options-schema'); location.reload()
    },
    saveForm(){
      const data = JSON.stringify(this.schema, null, 2)
      console.log('WIZARD JSON ->\n', data)
      downloadJson('wizard-schema.json', data)
      this.openJson = true
    },
    loadForm(e){
      const f = e.target.files[0]; if(!f) return
      const r = new FileReader()
      r.onload = () => {
        try{
          const obj = JSON.parse(r.result)
          // migrate
          if(obj.steps){ obj.steps.forEach(s => { if(!s.fields){ s.fields = [...(s.left || []), ...(s.right || [])]; delete s.left; delete s.right } }) }
          this.schema = obj; this.currentStepIndex = 0; this.selected = { step:0, index:-1 }
          this.persist()
        }catch{
          alert('Invalid JSON')
        }
      }
      r.readAsText(f); e.target.value=''
    },
    goBack(){ this.currentStepIndex = Math.max(0, this.currentStepIndex-1) },
    goNext(){ this.currentStepIndex = Math.min(this.schema.steps.length-1, this.currentStepIndex+1) },
  },
  watch: {
    schema: { deep: true, handler(){ this.persist() } }
  }
}
</script>
