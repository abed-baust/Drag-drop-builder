
<template>
  <div class="panel">
    <h3>Sidebar</h3>
    <div class="tabs3">
      <button :class="{active: tab==='elements'}" @click="tab='elements'">Elements</button>
      <button :class="{active: tab==='settings'}" @click="tab='settings'">Settings</button>
      <button :class="{active: tab==='checklist'}" @click="tab='checklist'">Checklist</button>
    </div>

    <div class="body" v-if="tab==='elements'">
      <div v-for="(g,gi) in groups" :key="gi" class="group">
        <h4>{{ g.title }} <span class="muted">ⓘ</span></h4>
        <div class="tileGrid">
          <div v-for="(t,ti) in g.items" :key="ti" class="tile" draggable="true" @dragstart="dragStart(t, $event)">
            <div style="font-size:18px">📄</div>
            <div>{{ t.label || t.value }}</div>
          </div>
        </div>
      </div>
    </div>

    <div class="body" v-else-if="tab==='settings'">
      <h4>Settings</h4>
      <label style="display:flex;align-items:center;gap:8px;margin-bottom:10px">
        <input type="checkbox" v-model="step.settings.published" /> Published
      </label>
      <div v-if="isSurvey">
        <label style="display:flex;align-items:center;gap:8px;margin-bottom:10px">
          <input type="checkbox" v-model="step.settings.surveyParticipantType" />
          Participant type enable in survey form
        </label>
      </div>
      <h4>Publishing Options</h4>
      <label style="display:flex;align-items:center;gap:8px;margin-bottom:10px">
        <input type="checkbox" v-model="step.checklist.published" /> Published
      </label>
      <div style="display:grid;grid-template-columns:1fr 1fr;gap:12px">
        <div><label class="muted">Start</label><input type="date" v-model="step.settings.publishStart" /></div>
        <div><label class="muted">End</label><input type="date" v-model="step.settings.publishEnd" /></div>
      </div>
    </div>

    <div class="body" v-else>
      <h4>Checklist</h4>
      <div v-for="(it, i) in step.checklist.items" :key="i" style="display:flex;gap:8px;align-items:center;margin-bottom:8px">
        <input type="checkbox" v-model="it.done" />
        <input type="text" v-model="it.text" style="flex:1" />
        <button class="btn" @click="step.checklist.items.splice(i,1)">✕</button>
      </div>
      <button class="btn" @click="step.checklist.items.push({text:'',done:false})">+ Add More</button>
    </div>
  </div>
</template>

<script>
import { surveyPalette, demoPalette } from '../data/palettes.js'
export default {
  name: 'Sidebar',
  props: { schema: { type: Object, required: true }, index: { type: Number, default: 0 } },
  emits: ['update:index'],
  data(){ return { tab: 'elements' } },
  computed: {
    step(){ return this.schema.steps[this.index] },
    isSurvey(){ return (this.step?.title || '').toLowerCase() === 'survey' },
    groups(){ return this.isSurvey ? surveyPalette : demoPalette }
  },
  methods: {
    dragStart(item, ev){ ev.dataTransfer.setData('text/plain', JSON.stringify(item)) }
  }
}
</script>
